# FFolders
Pure Css and customizable file folders icons

by 
@jlizanab
